package com.allfmradio.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class RadioBrowserApi {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS).build()
    private val base = "https://de1.api.radio-browser.info"

    suspend fun search(query: String = "", countryCode: String? = null, limit: Int = 100): List<RadioStation> = withContext(Dispatchers.IO) {
        val params = mutableListOf("hidebroken=true", "limit=$limit", "order=votes", "reverse=true")
        if (query.isNotBlank()) params += "name=${enc(query)}"
        if (!countryCode.isNullOrBlank()) params += "countrycode=${enc(countryCode)}"
        val request = Request.Builder().url("$base/json/stations/search?${params.joinToString("&")}")
            .header("User-Agent", "AllFMRadio/1.0 (Android)").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("Radio directory error: ${response.code}")
            val array = JSONArray(response.body?.string().orEmpty())
            buildList {
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    val url = o.optString("url_resolved").ifBlank { o.optString("url") }
                    if (url.isBlank()) continue
                    add(RadioStation(
                        uuid = o.optString("stationuuid"), name = o.optString("name", "Unknown station"),
                        country = o.optString("country"), state = o.optString("state"),
                        language = o.optString("language"), streamUrl = url,
                        favicon = o.optString("favicon"), homepage = o.optString("homepage"),
                        codec = o.optString("codec"), bitrate = o.optInt("bitrate")
                    ))
                }
            }
        }
    }

    suspend fun countClick(uuid: String) = withContext(Dispatchers.IO) {
        if (uuid.isBlank()) return@withContext
        val request = Request.Builder().url("$base/json/url/${enc(uuid)}")
            .header("User-Agent", "AllFMRadio/1.0 (Android)").build()
        runCatching { client.newCall(request).execute().close() }
    }

    private fun enc(value: String) = URLEncoder.encode(value, "UTF-8")
}
