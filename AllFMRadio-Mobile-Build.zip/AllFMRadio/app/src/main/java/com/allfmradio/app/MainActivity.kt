package com.allfmradio.app

import android.content.ComponentName
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.allfmradio.app.data.RadioBrowserApi
import com.allfmradio.app.data.RadioStation
import com.allfmradio.app.player.RadioPlaybackService
import java.util.concurrent.Executor
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, RadioPlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({ controller = future.get() }, Executor { it.run() })
        setContent { AllFmApp(this, controller) }
    }
    override fun onDestroy() { controller?.release(); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AllFmApp(context: Context, player: MediaController?) {
    val api = remember { RadioBrowserApi() }
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("allfm", Context.MODE_PRIVATE) }
    var stations by remember { mutableStateOf<List<RadioStation>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var country by remember { mutableStateOf("IN") }
    var selectedTab by remember { mutableStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var current by remember { mutableStateOf<RadioStation?>(null) }
    var playing by remember { mutableStateOf(false) }
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()) }

    fun load() {
        scope.launch {
            loading = true; error = ""
            try { stations = api.search(query, if (selectedTab == 1) null else country) }
            catch (e: Exception) { error = "स्टेशन लोड नहीं हुए। इंटरनेट जाँचकर फिर कोशिश करें।" }
            loading = false
        }
    }
    LaunchedEffect(selectedTab, country) { load() }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF20D6B0), secondary = Color(0xFF8B9CFF),
        background = Color(0xFF0B1020), surface = Color(0xFF151D31)
    )) {
        Scaffold(containerColor = Color(0xFF0B1020), bottomBar = {
            NavigationBar(containerColor = Color(0xFF11182A)) {
                NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Text("🇮🇳") }, label = { Text("India") })
                NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Text("🌍") }, label = { Text("World") })
                NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 }, icon = { Icon(Icons.Default.Favorite, null) }, label = { Text("Favorites") })
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                Spacer(Modifier.height(18.dp))
                Text("ALL FM RADIO", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text("Live radio • India & Worldwide", color = Color(0xFF9AA8C2), fontSize = 13.sp)
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("रेडियो स्टेशन खोजें…") }, leadingIcon = { Icon(Icons.Default.Search, null) },
                    singleLine = true, shape = RoundedCornerShape(16.dp), trailingIcon = {
                        TextButton(onClick = { load() }) { Text("खोजें") }
                    })
                if (selectedTab == 0) {
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = country == "IN", onClick = { country = "IN" }, label = { Text("India") })
                        Text("भारत के उपलब्ध ऑनलाइन स्टेशन", color = Color(0xFF9AA8C2), modifier = Modifier.align(Alignment.CenterVertically), fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))
                when {
                    loading -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    error.isNotBlank() -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text(error, color = Color.White) }
                    else -> {
                        val visible = when (selectedTab) {
                            2 -> stations.filter { favorites.contains(it.uuid) }
                            else -> stations
                        }
                        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            items(visible, key = { it.uuid }) { station ->
                                StationRow(station, favorites.contains(station.uuid), current?.uuid == station.uuid,
                                    onFavorite = {
                                        favorites = if (favorites.contains(station.uuid)) favorites - station.uuid else favorites + station.uuid
                                        prefs.edit().putStringSet("favorites", favorites).apply()
                                    }, onPlay = {
                                        current = station
                                        val item = MediaItem.Builder().setUri(station.streamUrl)
                                            .setMediaMetadata(MediaMetadata.Builder().setTitle(station.name).setArtist(station.country).build()).build()
                                        player?.setMediaItem(item); player?.prepare(); player?.play(); playing = true
                                        scope.launch { api.countClick(station.uuid) }
                                    })
                            }
                        }
                    }
                }
                current?.let { station ->
                    Surface(color = Color(0xFF1B2941), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("NOW PLAYING", color = Color(0xFF20D6B0), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text(station.name, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text(station.country, color = Color(0xFF9AA8C2), fontSize = 12.sp)
                            }
                            IconButton(onClick = { if (playing) { player?.pause(); playing = false } else { player?.play(); playing = true } }) {
                                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color(0xFF20D6B0), modifier = Modifier.size(34.dp))
                            }
                        }
                    }
                }
                Text("Station directory: Radio Browser • No ads • Stream availability may vary", color = Color(0xFF66738D), fontSize = 10.sp, modifier = Modifier.padding(bottom = 8.dp))
            }
        }
    }
}

@Composable
private fun StationRow(station: RadioStation, favorite: Boolean, isCurrent: Boolean, onFavorite: () -> Unit, onPlay: () -> Unit) {
    Surface(color = if (isCurrent) Color(0xFF1B3A43) else Color(0xFF151D31), shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth().clickable { onPlay() }) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(43.dp).background(Color(0xFF253650), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Text("📻", fontSize = 21.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(station.name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(listOf(station.country, station.language, if (station.bitrate > 0) "${station.bitrate} kbps" else "").filter { it.isNotBlank() }.joinToString(" • "), color = Color(0xFF9AA8C2), fontSize = 11.sp, maxLines = 1)
            }
            IconButton(onClick = onFavorite) { Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (favorite) Color(0xFFFF6B91) else Color(0xFF9AA8C2)) }
            Icon(Icons.Default.PlayArrow, null, tint = Color(0xFF20D6B0))
        }
    }
}
