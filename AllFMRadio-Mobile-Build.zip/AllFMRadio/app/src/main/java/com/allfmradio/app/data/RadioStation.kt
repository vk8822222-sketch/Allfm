package com.allfmradio.app.data

data class RadioStation(
    val uuid: String,
    val name: String,
    val country: String,
    val state: String,
    val language: String,
    val streamUrl: String,
    val favicon: String,
    val homepage: String,
    val codec: String,
    val bitrate: Int
)
