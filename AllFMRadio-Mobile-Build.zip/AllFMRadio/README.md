# All FM Radio (Android)

An ad-free Android internet-radio starter app built with Kotlin, Jetpack Compose and AndroidX Media3.

## Features in this starter
- India and worldwide station browsing
- Search station names
- Favorites saved locally
- Streaming through Media3 ExoPlayer
- MediaSessionService for background playback and Android media controls
- No ad SDKs, analytics SDKs, login, or user account
- Station directory powered by the free Radio Browser API

## Open and build
1. Install Android Studio (Ladybug or newer) with Android SDK Platform 35 and JDK 17.
2. Open this `AllFMRadio` folder in Android Studio.
3. Allow Gradle sync and dependency downloads.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

Command line (on a machine with Android SDK installed):

```bash
gradle assembleDebug
```

## Important limitations / release checklist
- Radio Browser is a community-maintained directory, not a guarantee that every FM broadcaster is listed or that every stream works. The directory API itself says availability is not guaranteed. See https://api.radio-browser.info/ and https://docs.radio-browser.info/.
- A station's listing does not itself grant rebroadcast rights. Before publishing, verify the broadcaster's stream terms/permission and remove stations that prohibit third-party playback. Do not re-host or record streams.
- This starter currently uses the documented `de1.api.radio-browser.info` API host. For a production release, implement the documented mirror discovery flow via `all.api.radio-browser.info`, plus retries and caching.
- The app is ad-free by design: no ad SDK is included. The free public directory can have downtime; no service-level guarantee is provided.
- Test playback on physical devices, especially background playback, Bluetooth, headset controls, Android 13+ notification permission, and OEM battery restrictions.
- Add a proper app icon, privacy policy, support contact, and store listing before Play Store release.

## Package
`com.allfmradio.app`

## License note
This project code is provided as a starter. Radio Browser data and individual station streams are provided by their respective operators/communities and remain subject to their terms.
